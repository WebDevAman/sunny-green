export const navData = [
    {
        title: "PRIVATE PERSON",
        slug: '/private-person'
    },
    {
        title: "ZAKELIJK",
        slug: '/zakelijk'
    },
    {
        title: "OVER ONS",
        slug: '/over-ons'
    },
]