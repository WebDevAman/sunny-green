import { atom } from "recoil";

export const atomImageFromGoogle = atom({
    key: "GOOGLE_IMAGE_FROM_API",
    default: {}
})